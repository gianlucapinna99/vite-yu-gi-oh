<script>
    export default{
        name: "AppHeader",
    }
</script>

<template>
    <header>
        <div class="container">
            <h1>Yu-Gi-Oh Api</h1>
        </div>       
    </header>
</template>



<style lang="scss" scoped>

</style>